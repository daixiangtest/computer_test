#!/bin/bash
cd allure-2.9.0
cd bin
allure open ../../allure_html